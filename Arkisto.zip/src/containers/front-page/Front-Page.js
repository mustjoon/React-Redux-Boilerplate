import React, { Component } from 'react';
import Link from '@common/link/Link';

class FrontPage extends Component {
  
  render() {
    return (
      <div>
      <Link to='/sub'>Test</Link>
        Frontpage
      
      </div>
    );
  }
}

export default FrontPage;
