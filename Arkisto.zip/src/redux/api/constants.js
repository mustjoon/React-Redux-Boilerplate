export const API = {
  base: '/'
}